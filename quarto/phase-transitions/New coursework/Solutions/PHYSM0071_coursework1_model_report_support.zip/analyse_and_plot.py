"""Analyse cached lattice-gas runs and make the model-report figures."""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from scipy.stats import binom


ROOT = Path(__file__).resolve().parent
RUNS = ROOT / "runs"
FIGURES = ROOT / "figures"
FIGURES.mkdir(parents=True, exist_ok=True)
PROGRAM = ROOT / "Full_lattice_gas_GCE.py"

spec = importlib.util.spec_from_file_location("supplied_lattice_gas", PROGRAM)
lg = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(lg)

TC = float(lg.exact_critical_temperature(1.0))
MU_COEX = float(lg.coexistence_chemical_potential(1.0))
BASE_SEED = 2_468_135

plt.style.use("tableau-colorblind10")
plt.rcParams.update(
    {
        "font.size": 8.5,
        "axes.labelsize": 8.5,
        "axes.titlesize": 9,
        "legend.fontsize": 7.5,
        "xtick.labelsize": 7.5,
        "ytick.labelsize": 7.5,
        "figure.dpi": 130,
        "savefig.dpi": 300,
        "axes.spines.top": False,
        "axes.spines.right": False,
    }
)


def load_run(key: str) -> dict:
    with np.load(RUNS / f"{key}.npz") as archive:
        result = {name: archive[name].copy() for name in archive.files}
    result["metadata"] = json.loads(str(result["metadata"]))
    return result


def integrated_autocorrelation_time(values, window_constant: float = 6.0):
    x = np.asarray(values, dtype=float)
    x = x - x.mean()
    n = x.size
    n_fft = 1 << (2 * n - 1).bit_length()
    transform = np.fft.rfft(x, n=n_fft)
    acov = np.fft.irfft(transform * transform.conjugate(), n=n_fft)[:n]
    acov /= np.arange(n, 0, -1)
    if acov[0] <= 0:
        return 0.5, np.ones(1)
    acf = acov / acov[0]
    tau = 0.5
    stop = 1
    for stop in range(1, n):
        tau = max(0.5, 0.5 + np.sum(acf[1 : stop + 1]))
        if stop >= window_constant * tau:
            break
    return float(tau), acf[: stop + 1]


def blocked_mean_and_variance(values):
    x = np.asarray(values, dtype=float)
    tau, _ = integrated_autocorrelation_time(x)
    block_length = max(20, int(np.ceil(10.0 * tau)))
    block_length = min(block_length, max(20, x.size // 12))
    n_blocks = x.size // block_length
    trimmed = x[: n_blocks * block_length].reshape(n_blocks, block_length)
    block_means = trimmed.mean(axis=1)
    block_variances = trimmed.var(axis=1)
    mean_sem = block_means.std(ddof=1) / np.sqrt(n_blocks)
    variance_sem = block_variances.std(ddof=1) / np.sqrt(n_blocks)
    return {
        "mean": float(x.mean()),
        "mean_sem": float(mean_sem),
        "variance": float(x.var()),
        "variance_sem": float(variance_sem),
        "tau_measurements": float(tau),
        "block_length": int(block_length),
        "n_blocks": int(n_blocks),
    }


def discrete_probability(particle_samples, volume):
    probability = np.bincount(
        np.asarray(particle_samples, dtype=int), minlength=volume + 1
    ).astype(float)
    probability /= probability.sum()
    rho = np.arange(volume + 1) / volume
    return rho, probability


def coarse_histogram(values, bins):
    probability, edges = np.histogram(values, bins=bins, density=False)
    probability = probability.astype(float) / probability.sum()
    centres = 0.5 * (edges[:-1] + edges[1:])
    return centres, probability


def panel_label(ax, label):
    ax.text(
        0.02,
        0.96,
        label,
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontweight="bold",
        bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.75},
    )


def save_figure(fig, stem):
    fig.savefig(FIGURES / f"{stem}.pdf", bbox_inches="tight")
    fig.savefig(FIGURES / f"{stem}.png", bbox_inches="tight")
    plt.close(fig)


def validation_analysis(summary):
    ideal_rows = []
    for mu in (-1.0, 0.0, 1.0):
        run = load_run(f"ideal_mu{mu:+.1f}")
        N = run["particle_samples"]
        stats = blocked_mean_and_variance(N)
        p = np.exp(mu) / (1.0 + np.exp(mu))
        stats.update(
            {
                "mu": mu,
                "mean_exact": 400.0 * p,
                "variance_exact": 400.0 * p * (1.0 - p),
                "acceptance": run["metadata"]["acceptance_sampling"],
            }
        )
        ideal_rows.append(stats)

    low = load_run("ph_mu-2.4")
    high = load_run("ph_mu-1.6")
    low_stats = blocked_mean_and_variance(low["particle_samples"] / 400.0)
    high_stats = blocked_mean_and_variance(high["particle_samples"] / 400.0)
    symmetry_difference = (
        high_stats["mean"] - (1.0 - low_stats["mean"])
    )
    symmetry_sem = np.hypot(
        high_stats["mean_sem"], low_stats["mean_sem"]
    )

    summary["validation"] = {
        "ideal": ideal_rows,
        "particle_hole": {
            "rho_minus": low_stats,
            "rho_plus": high_stats,
            "difference": float(symmetry_difference),
            "difference_sem": float(symmetry_sem),
        },
    }

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 2.45))
    run_distribution = load_run("ideal_mu-1.0")
    density = run_distribution["particle_samples"] / 400.0
    axes[0].plot(np.arange(900) * 5, density[:900], lw=0.65)
    p_distribution = np.exp(-1.0) / (1.0 + np.exp(-1.0))
    axes[0].axhline(p_distribution, color="black", ls="--", lw=0.9)
    axes[0].set(
        xlabel="sampling sweeps",
        ylabel=r"$\rho$",
        title=r"Noninteracting run: $\mu=-1$",
    )
    panel_label(axes[0], "(a)")

    N = run_distribution["particle_samples"]
    values = np.arange(N.min(), N.max() + 1)
    probability = np.bincount(N, minlength=401) / N.size
    axes[1].step(
        values,
        probability[values],
        where="mid",
        lw=1.2,
        label="simulation",
    )
    axes[1].plot(
        values,
        binom.pmf(values, 400, p_distribution),
        "o",
        ms=2.5,
        mfc="none",
        label="binomial",
    )
    axes[1].set(
        xlabel=r"$N$",
        ylabel=r"$P(N)$",
        title="Complete number distribution",
    )
    axes[1].legend(frameon=False)
    panel_label(axes[1], "(b)")
    fig.tight_layout(w_pad=2)
    save_figure(fig, "figure1_validation")


def eos_key(ratio, delta):
    if abs(delta) == 0.005:
        return f"eosfine_r{ratio:.2f}_dmu{delta:+.3f}"
    return f"eos_r{ratio:.2f}_dmu{delta:+.2f}"


def eos_analysis(summary):
    offsets = np.asarray(
        (
            -0.60,
            -0.40,
            -0.20,
            -0.10,
            -0.05,
            -0.02,
            -0.01,
            -0.005,
            0.0,
            0.005,
            0.01,
            0.02,
            0.05,
            0.10,
            0.20,
            0.40,
            0.60,
        )
    )
    eos_results = {}
    for ratio in (1.5, 1.15):
        rows = []
        for delta in offsets:
            run = load_run(eos_key(ratio, float(delta)))
            rho = run["particle_samples"] / 576.0
            stats = blocked_mean_and_variance(rho)
            stats.update(
                {
                    "delta_mu": float(delta),
                    "mu": MU_COEX + float(delta),
                    "acceptance": run["metadata"]["acceptance_sampling"],
                }
            )
            rows.append(stats)

        derivative_rows = []
        by_delta = {row["delta_mu"]: row for row in rows}
        for h in (0.05, 0.02, 0.01, 0.005):
            minus = by_delta[-h]
            plus = by_delta[h]
            derivative = (plus["mean"] - minus["mean"]) / (2.0 * h)
            derivative_sem = np.hypot(
                plus["mean_sem"], minus["mean_sem"]
            ) / (2.0 * h)
            derivative_rows.append(
                {
                    "h": h,
                    "value": float(derivative),
                    "sem": float(derivative_sem),
                }
            )

        coexistence = by_delta[0.0]
        T = ratio * TC
        chi_variance = 576.0 * coexistence["variance"] / T
        chi_variance_sem = 576.0 * coexistence["variance_sem"] / T
        coexistence_run = load_run(eos_key(ratio, 0.0))
        chi_structure = (
            coexistence_run["structure_factor"][12, 12] / T
        )

        pair_deviations = []
        for delta in offsets[offsets > 0]:
            minus = by_delta[-float(delta)]
            plus = by_delta[float(delta)]
            pair_deviations.append(
                plus["mean"] + minus["mean"] - 1.0
            )

        eos_results[str(ratio)] = {
            "rows": rows,
            "derivatives": derivative_rows,
            "chi_variance": float(chi_variance),
            "chi_variance_sem": float(chi_variance_sem),
            "chi_structure": float(chi_structure),
            "max_particle_hole_deviation": float(
                np.max(np.abs(pair_deviations))
            ),
        }

    summary["equation_of_state"] = eos_results

    fig, axes = plt.subplots(1, 2, figsize=(7.25, 2.65))
    colours = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    for colour, ratio in zip(colours, (1.5, 1.15)):
        rows = eos_results[str(ratio)]["rows"]
        x = np.asarray([row["mu"] for row in rows])
        y = np.asarray([row["mean"] for row in rows])
        error = np.asarray([row["mean_sem"] for row in rows])
        axes[0].errorbar(
            x,
            y,
            yerr=error,
            marker="o",
            ms=3,
            lw=1.1,
            capsize=1.5,
            label=rf"$T={ratio:g}T_c$",
            color=colour,
        )
    axes[0].axvline(MU_COEX, color="0.45", ls="--", lw=0.8)
    axes[0].axhline(0.5, color="0.7", ls=":", lw=0.8)
    axes[0].set(
        xlabel=r"$\mu$",
        ylabel=r"$\langle\rho\rangle$",
        title="Equation of state",
    )
    axes[0].legend(frameon=False)
    panel_label(axes[0], "(a)")

    markers = ("o", "s")
    for marker, ratio in zip(markers, (1.5, 1.15)):
        derivative_rows = eos_results[str(ratio)]["derivatives"]
        h = np.asarray([row["h"] for row in derivative_rows])
        value = np.asarray([row["value"] for row in derivative_rows])
        error = np.asarray([row["sem"] for row in derivative_rows])
        axes[1].errorbar(
            h,
            value,
            yerr=error,
            marker=marker,
            ms=4,
            capsize=2,
            lw=1,
            label=rf"finite difference, ${ratio:g}T_c$",
        )
        axes[1].axhline(
            eos_results[str(ratio)]["chi_variance"],
            color=colours[0 if ratio == 1.5 else 1],
            ls="--",
            lw=1,
        )
    axes[1].set_xscale("log")
    axes[1].invert_xaxis()
    axes[1].set(
        xlabel=r"finite-difference half-width $h$",
        ylabel=r"$\chi_\rho$",
        title="Density response at coexistence",
    )
    axes[1].legend(frameon=False, fontsize=6.8)
    panel_label(axes[1], "(b)")
    fig.tight_layout(w_pad=2)
    save_figure(fig, "figure2_equation_of_state")


def ornstein_zernike(k, amplitude, xi):
    return amplitude / (1.0 + (k * xi) ** 2)


def fit_structure_factor(k, mean_S, sem_S, k_max):
    mask = k <= k_max
    sigma = np.maximum(sem_S[mask], 0.02 * mean_S[mask])
    parameters, covariance = curve_fit(
        ornstein_zernike,
        k[mask],
        mean_S[mask],
        p0=(mean_S[0], 2.0),
        sigma=sigma,
        absolute_sigma=True,
        bounds=(0.0, np.inf),
        maxfev=20_000,
    )
    residual = (mean_S[mask] - ornstein_zernike(k[mask], *parameters))
    reduced_chi_squared = np.sum((residual / sigma) ** 2) / (
        mask.sum() - 2
    )
    return parameters, covariance, mask, reduced_chi_squared


def correlation_analysis(summary):
    rng = np.random.default_rng(92741)
    ratios = (1.50, 1.25, 1.10, 1.05)
    results = {}
    curves = {}
    for ratio in ratios:
        radial_curves = []
        configurations = []
        for replicate in range(1, 7):
            run = load_run(f"corr_r{ratio:.2f}_rep{replicate}")
            shell, S_radial, degeneracy = lg.radial_shell_average(
                run["structure_factor"]
            )
            k = 2.0 * np.pi * shell / 24.0
            radial_curves.append(S_radial)
            configurations.append(run["lattice"])
        radial_curves = np.asarray(radial_curves)
        mean_S = radial_curves.mean(axis=0)
        sem_S = radial_curves.std(axis=0, ddof=1) / np.sqrt(
            radial_curves.shape[0]
        )

        sensitivity = {}
        for k_max in (0.55, 0.75, 0.95):
            parameters, covariance, mask, reduced_chi_squared = (
                fit_structure_factor(k, mean_S, sem_S, k_max)
            )
            sensitivity[f"{k_max:.2f}"] = {
                "amplitude": float(parameters[0]),
                "xi": float(parameters[1]),
                "xi_fit_sem": float(np.sqrt(covariance[1, 1])),
                "n_wavevector_shells": int(mask.sum()),
                "reduced_chi_squared": float(reduced_chi_squared),
            }

        # Statistical uncertainty from resampling the six independent runs.
        xi_bootstrap = []
        for _ in range(1500):
            selection = rng.integers(0, radial_curves.shape[0],
                                     radial_curves.shape[0])
            bootstrap_mean = radial_curves[selection].mean(axis=0)
            bootstrap_sem = np.maximum(
                radial_curves[selection].std(axis=0, ddof=1)
                / np.sqrt(radial_curves.shape[0]),
                1.0e-8,
            )
            try:
                parameters, _, _, _ = fit_structure_factor(
                    k, bootstrap_mean, bootstrap_sem, 0.75
                )
                xi_bootstrap.append(parameters[1])
            except (RuntimeError, ValueError):
                pass

        central = sensitivity["0.75"]
        central["xi_bootstrap_sem"] = float(np.std(xi_bootstrap, ddof=1))
        results[str(ratio)] = {
            "temperature": ratio * TC,
            "reduced_temperature": ratio - 1.0,
            "central_fit": central,
            "kmax_sensitivity": sensitivity,
        }
        curves[ratio] = {
            "k": k,
            "mean": mean_S,
            "sem": sem_S,
            "configuration": configurations[0],
        }

    t = np.asarray([results[str(r)]["reduced_temperature"] for r in ratios])
    xi = np.asarray([results[str(r)]["central_fit"]["xi"] for r in ratios])
    xi_sem = np.asarray(
        [results[str(r)]["central_fit"]["xi_bootstrap_sem"] for r in ratios]
    )
    coefficients, covariance = np.polyfit(
        np.log(t), np.log(xi), 1, w=1.0 / np.maximum(xi_sem / xi, 1e-3),
        cov=True
    )
    exponent = -coefficients[0]
    exponent_sem = np.sqrt(covariance[0, 0])

    sensitivity_exponents = {}
    for k_max in ("0.55", "0.75", "0.95"):
        this_xi = np.asarray(
            [results[str(r)]["kmax_sensitivity"][k_max]["xi"] for r in ratios]
        )
        sensitivity_exponents[k_max] = float(
            -np.polyfit(np.log(t), np.log(this_xi), 1)[0]
        )

    summary["correlations"] = {
        "fits": results,
        "effective_exponent": float(exponent),
        "effective_exponent_fit_sem": float(exponent_sem),
        "exponent_kmax_sensitivity": sensitivity_exponents,
    }

    fig = plt.figure(figsize=(7.25, 5.05))
    grid = fig.add_gridspec(2, 4, height_ratios=(1.0, 1.15), hspace=0.36,
                           wspace=0.32)
    for index, ratio in enumerate(ratios):
        ax = fig.add_subplot(grid[0, index])
        ax.imshow(curves[ratio]["configuration"], cmap="gray_r", vmin=0, vmax=1)
        ax.set_title(rf"$T/T_c={ratio:.2f}$")
        ax.set_xticks([])
        ax.set_yticks([])
        panel_label(ax, f"({chr(97 + index)})")

    ax_s = fig.add_subplot(grid[1, :2])
    colours = plt.rcParams["axes.prop_cycle"].by_key()["color"]
    for colour, ratio in zip(colours, ratios):
        curve = curves[ratio]
        fit = results[str(ratio)]["central_fit"]
        mask = curve["k"] <= 1.15
        ax_s.errorbar(
            curve["k"][mask],
            curve["mean"][mask],
            yerr=curve["sem"][mask],
            marker="o",
            ms=2.5,
            lw=0,
            capsize=1,
            label=rf"${ratio:.2f}T_c$",
            color=colour,
        )
        k_line = np.linspace(0, 0.75, 200)
        ax_s.plot(
            k_line,
            ornstein_zernike(
                k_line, fit["amplitude"], fit["xi"]
            ),
            lw=1,
            color=colour,
        )
    ax_s.set_yscale("log")
    ax_s.set(
        xlabel=r"$k$",
        ylabel=r"$S(k)$",
        title=r"Connected structure factor; fits use $k\leq0.75$",
    )
    ax_s.legend(frameon=False, ncol=2)
    panel_label(ax_s, "(e)")

    ax_xi = fig.add_subplot(grid[1, 2])
    ax_xi.errorbar(t, xi, yerr=xi_sem, fmt="o", capsize=2, label="fits")
    t_line = np.geomspace(t.min(), t.max(), 100)
    amplitude = np.exp(coefficients[1])
    ax_xi.plot(
        t_line,
        amplitude * t_line ** (-exponent),
        lw=1.2,
        label=rf"$t^{{-{exponent:.2f}}}$",
    )
    anchor = xi[-1]
    ax_xi.plot(
        t_line,
        anchor * (t_line / t[-1]) ** (-1.0),
        ls="--",
        lw=0.9,
        label=r"$\nu=1$",
    )
    ax_xi.plot(
        t_line,
        anchor * (t_line / t[-1]) ** (-0.5),
        ls=":",
        lw=0.9,
        label=r"$\nu=1/2$",
    )
    ax_xi.set_xscale("log")
    ax_xi.set_yscale("log")
    ax_xi.set(
        xlabel=r"$t=(T-T_c)/T_c$",
        ylabel=r"$\xi$",
        title="Correlation length",
    )
    ax_xi.legend(frameon=False, fontsize=6.5)
    panel_label(ax_xi, "(f)")

    ax_sens = fig.add_subplot(grid[1, 3])
    for ratio in ratios:
        kmax = np.asarray((0.55, 0.75, 0.95))
        xi_k = np.asarray(
            [
                results[str(ratio)]["kmax_sensitivity"][f"{value:.2f}"]["xi"]
                for value in kmax
            ]
        )
        ax_sens.plot(kmax, xi_k, marker="o", ms=3, label=rf"${ratio:.2f}T_c$")
    ax_sens.set(
        xlabel=r"upper fit limit $k_{\max}$",
        ylabel=r"$\xi$",
        title="Fit-range sensitivity",
    )
    ax_sens.legend(frameon=False, fontsize=6.5)
    panel_label(ax_sens, "(g)")
    save_figure(fig, "figure3_correlations")


def density_distribution_analysis(summary):
    run_hot = load_run("dist_r1.20")
    run_critical = load_run("critlong_L20")
    run_low = load_run("dist_r0.90_low")
    run_high = load_run("dist_r0.90_high")

    rho_hot = run_hot["particle_samples"] / 400.0
    rho_critical = run_critical["particle_samples"] / 400.0
    rho_low = run_low["particle_samples"] / 400.0
    rho_high = run_high["particle_samples"] / 400.0

    symmetry = {}
    for label, values in (("1.20", rho_hot), ("1.00", rho_critical)):
        _, probability = discrete_probability(np.rint(values * 400), 400)
        symmetry[label] = {
            "mean_density": float(values.mean()),
            "reflection_total_variation": float(
                0.5 * np.abs(probability - probability[::-1]).sum()
            ),
        }

    def switches(values):
        sector = np.where(values >= 0.5, 1, -1)
        return int(np.count_nonzero(sector[1:] != sector[:-1]))

    summary["density_distributions"] = {
        "symmetry": symmetry,
        "subcritical_low": {
            "mean_density": float(rho_low.mean()),
            "minimum": float(rho_low.min()),
            "maximum": float(rho_low.max()),
            "sector_switches": switches(rho_low),
        },
        "subcritical_high": {
            "mean_density": float(rho_high.mean()),
            "minimum": float(rho_high.min()),
            "maximum": float(rho_high.max()),
            "sector_switches": switches(rho_high),
        },
    }

    fig, axes = plt.subplots(2, 3, figsize=(7.25, 4.25))
    time_series = (
        (rho_hot, r"$1.20T_c$"),
        (rho_critical, r"$T_c$"),
        ((rho_low, rho_high), r"$0.90T_c$"),
    )
    for column, (values, title) in enumerate(time_series):
        ax = axes[0, column]
        if isinstance(values, tuple):
            for data, label in zip(values, ("low start", "high start")):
                step = max(1, len(data) // 3000)
                ax.plot(
                    np.arange(0, len(data), step) * 5,
                    data[::step],
                    lw=0.55,
                    label=label,
                )
            ax.legend(frameon=False, fontsize=6.5)
        else:
            step = max(1, len(values) // 3000)
            ax.plot(
                np.arange(0, len(values), step) * 5,
                values[::step],
                lw=0.55,
            )
        ax.axhline(0.5, color="0.5", ls=":", lw=0.7)
        ax.set_title(title)
        ax.set_ylim(-0.02, 1.02)
        if column == 0:
            ax.set_ylabel(r"$\rho$")
        ax.set_xlabel("sampling sweeps")
        panel_label(ax, f"({chr(97 + column)})")

    for column, (values, title) in enumerate(
        ((rho_hot, r"$1.20T_c$"), (rho_critical, r"$T_c$"))
    ):
        N = np.rint(values * 400).astype(int)
        rho_grid, probability = discrete_probability(N, 400)
        axes[1, column].plot(rho_grid, probability, lw=1.1, label=r"$P_L(\rho)$")
        axes[1, column].plot(
            rho_grid,
            probability[::-1],
            ls="--",
            lw=0.9,
            label=r"$P_L(1-\rho)$",
        )
        axes[1, column].set_title(title)
        axes[1, column].set_xlabel(r"$\rho$")
        if column == 0:
            axes[1, column].set_ylabel(r"$P_L(\rho)$")
        axes[1, column].legend(frameon=False, fontsize=6.5)
        panel_label(axes[1, column], f"({chr(100 + column)})")

    _, probability_high = discrete_probability(
        run_high["particle_samples"], 400
    )
    probability_symmetric = 0.5 * (
        probability_high + probability_high[::-1]
    )
    rho_grid = np.arange(401) / 400.0
    axes[1, 2].plot(
        rho_grid,
        probability_symmetric,
        lw=1.1,
        label="symmetry-enforced estimate",
    )
    axes[1, 2].set(
        xlabel=r"$\rho$",
        title=r"$0.90T_c$",
    )
    axes[1, 2].legend(frameon=False, fontsize=6.3)
    panel_label(axes[1, 2], "(f)")
    fig.tight_layout(h_pad=1.4, w_pad=1.0)
    save_figure(fig, "figure4_density_distributions")


def binder_cumulant(values):
    m2 = np.mean(values**2)
    m4 = np.mean(values**4)
    return 1.0 - m4 / (3.0 * m2**2)


def blocked_bootstrap_binder(run_values, rng, n_bootstrap=2500):
    tau_values = [
        integrated_autocorrelation_time(values**2)[0]
        for values in run_values
    ]
    block_length = max(100, int(np.ceil(8.0 * max(tau_values))))
    block_length = min(
        block_length, min(values.size for values in run_values) // 10
    )
    block_moments = []
    for values in run_values:
        n_blocks = values.size // block_length
        blocks = values[: n_blocks * block_length].reshape(
            n_blocks, block_length
        )
        for block in blocks:
            block_moments.append((np.mean(block**2), np.mean(block**4)))
    block_moments = np.asarray(block_moments)
    estimates = np.empty(n_bootstrap)
    for index in range(n_bootstrap):
        selection = rng.integers(
            0, block_moments.shape[0], block_moments.shape[0]
        )
        m2, m4 = block_moments[selection].mean(axis=0)
        estimates[index] = 1.0 - m4 / (3.0 * m2**2)
    pooled = np.concatenate(run_values)
    return {
        "value": float(binder_cumulant(pooled)),
        "sem": float(estimates.std(ddof=1)),
        "block_length_measurements": int(block_length),
        "n_blocks": int(block_moments.shape[0]),
        "tau_m2_measurements": float(max(tau_values)),
    }


def critical_analysis(summary):
    rng = np.random.default_rng(11811)
    results = {}
    distributions = {}
    for L in (12, 16, 20, 24):
        run_values = []
        for replicate in (1, 2):
            run = load_run(f"crit_L{L}_rep{replicate}")
            rho = run["particle_samples"] / float(L * L)
            run_values.append(2.0 * rho - 1.0)
        binder = blocked_bootstrap_binder(run_values, rng)
        results[str(L)] = binder
        pooled_rho = 0.5 * (np.concatenate(run_values) + 1.0)
        distributions[L] = pooled_rho

    diagnostic_run = load_run("critlong_L24")
    rho_diagnostic = diagnostic_run["particle_samples"] / 576.0
    m_diagnostic = 2.0 * rho_diagnostic - 1.0
    tau_m, _ = integrated_autocorrelation_time(m_diagnostic)
    tau_m2, _ = integrated_autocorrelation_time(m_diagnostic**2)
    effective_samples = rho_diagnostic.size / (2.0 * tau_m)
    bins = np.linspace(0.0, 1.0, 41)
    centres, first = coarse_histogram(
        rho_diagnostic[: rho_diagnostic.size // 2], bins
    )
    _, second = coarse_histogram(
        rho_diagnostic[rho_diagnostic.size // 2 :], bins
    )
    half_tv = 0.5 * np.abs(first - second).sum()
    sector = np.where(rho_diagnostic >= 0.5, 1, -1)
    sector_switches = np.count_nonzero(sector[1:] != sector[:-1])

    summary["critical"] = {
        "binder": results,
        "diagnostic_L24_long": {
            "tau_m_measurements": float(tau_m),
            "tau_m_sweeps": float(
                tau_m
                * diagnostic_run["metadata"]["n_sweeps_per_meas"]
            ),
            "tau_m2_measurements": float(tau_m2),
            "effective_samples": float(effective_samples),
            "first_second_half_total_variation": float(half_tv),
            "sector_switches": int(sector_switches),
            "mean_first_half": float(
                rho_diagnostic[: rho_diagnostic.size // 2].mean()
            ),
            "mean_second_half": float(
                rho_diagnostic[rho_diagnostic.size // 2 :].mean()
            ),
        },
    }

    fig, axes = plt.subplots(1, 3, figsize=(7.25, 2.55))
    for L in (12, 16, 20, 24):
        bins_L = np.linspace(0.0, 1.0, 61)
        centres_L, probability = coarse_histogram(distributions[L], bins_L)
        density = probability / np.diff(bins_L)
        axes[0].plot(centres_L, density, lw=1.0, label=rf"$L={L}$")
    axes[0].set(
        xlabel=r"$\rho$",
        ylabel=r"probability density",
        title=r"Critical $P_L(\rho)$",
    )
    axes[0].legend(frameon=False, fontsize=6.7)
    panel_label(axes[0], "(a)")

    sizes = np.asarray((12, 16, 20, 24))
    binder_values = np.asarray([results[str(L)]["value"] for L in sizes])
    binder_errors = np.asarray([results[str(L)]["sem"] for L in sizes])
    axes[1].errorbar(
        1.0 / sizes,
        binder_values,
        yerr=binder_errors,
        fmt="o",
        capsize=2,
    )
    axes[1].axhline(0.61069, color="black", ls="--", lw=0.9,
                    label=r"$U_4^*=0.61069$")
    axes[1].set(
        xlabel=r"$1/L$",
        ylabel=r"$U_4$",
        title="Binder cumulant",
    )
    axes[1].legend(frameon=False, fontsize=6.8)
    panel_label(axes[1], "(b)")

    axes[2].step(centres, first, where="mid", lw=1, label="first half")
    axes[2].step(centres, second, where="mid", lw=1, label="second half")
    axes[2].set(
        xlabel=r"$\rho$",
        ylabel="probability",
        title=r"$L=24$ convergence check",
    )
    axes[2].legend(frameon=False, fontsize=6.8, loc="lower center")
    inset = axes[2].inset_axes([0.48, 0.43, 0.49, 0.47])
    step = 10
    inset.plot(
        np.arange(0, rho_diagnostic.size, step) * 5,
        rho_diagnostic[::step],
        lw=0.35,
    )
    inset.axhline(0.5, color="0.5", ls=":", lw=0.6)
    inset.set_xlabel("sweeps", fontsize=5.8)
    inset.set_ylabel(r"$\rho$", fontsize=5.8)
    inset.tick_params(labelsize=5.5)
    panel_label(axes[2], "(c)")
    fig.tight_layout(w_pad=1.4)
    save_figure(fig, "figure5_critical_finite_size")


def write_run_table():
    used_keys = []
    used_keys.extend([f"ideal_mu{mu:+.1f}" for mu in (-1.0, 0.0, 1.0)])
    used_keys.extend(("ph_mu-2.4", "ph_mu-1.6"))
    for ratio in (1.5, 1.15):
        for delta in (
            -0.60,
            -0.40,
            -0.20,
            -0.10,
            -0.05,
            -0.02,
            -0.01,
            -0.005,
            0.0,
            0.005,
            0.01,
            0.02,
            0.05,
            0.10,
            0.20,
            0.40,
            0.60,
        ):
            used_keys.append(eos_key(ratio, delta))
    for ratio in (1.50, 1.25, 1.10, 1.05):
        used_keys.extend(
            [f"corr_r{ratio:.2f}_rep{replicate}" for replicate in range(1, 7)]
        )
    used_keys.extend(("dist_r1.20", "dist_r0.90_low", "dist_r0.90_high"))
    for L in (12, 16, 20, 24):
        used_keys.extend(
            [f"crit_L{L}_rep{replicate}" for replicate in (1, 2)]
        )
    used_keys.extend(("critlong_L20", "critlong_L24"))

    rows = []
    for key in used_keys:
        metadata = load_run(key)["metadata"]
        rows.append(metadata)
    rows.sort(key=lambda row: row["run_id"])
    columns = (
        "key",
        "run_id",
        "L",
        "T",
        "mu",
        "epsilon",
        "initial_density",
        "seed",
        "n_sweeps_eq",
        "n_sweeps_per_meas",
        "n_meas",
        "acceptance_sampling",
    )
    with open(ROOT / "production_run_table.csv", "w", encoding="utf-8") as out:
        out.write(",".join(columns) + "\n")
        for row in rows:
            out.write(",".join(str(row[column]) for column in columns) + "\n")


def main():
    summary = {
        "base_seed": BASE_SEED,
        "critical_temperature": TC,
        "coexistence_chemical_potential": MU_COEX,
    }
    validation_analysis(summary)
    eos_analysis(summary)
    correlation_analysis(summary)
    density_distribution_analysis(summary)
    critical_analysis(summary)
    write_run_table()
    with open(ROOT / "analysis_summary.json", "w", encoding="utf-8") as out:
        json.dump(summary, out, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
