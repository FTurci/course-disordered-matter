"""Run and cache the simulations used in the PHYSM0071 model report.

The Monte Carlo implementation is imported unchanged from the supplied
Full_lattice_gas_GCE.py program.  This driver only defines the requested
state points, assigns reproducible seeds, and caches each returned dictionary.
"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import time

import numpy as np


ROOT = Path(__file__).resolve().parent
PROGRAM = ROOT / "Full_lattice_gas_GCE.py"
RUN_DIRECTORY = ROOT / "runs"
RUN_DIRECTORY.mkdir(parents=True, exist_ok=True)

spec = importlib.util.spec_from_file_location("supplied_lattice_gas", PROGRAM)
lg = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(lg)

# Suppress progress bars in the batch log.  This does not alter the simulation.
lg.tqdm = lambda iterable, **_kwargs: iterable

BASE_SEED = 2_468_135
EPSILON = 1.0
TC = float(lg.exact_critical_temperature(EPSILON))
MU_COEX = float(lg.coexistence_chemical_potential(EPSILON))


def seed_for(run_id: int) -> int:
    return (BASE_SEED + 104_729 * int(run_id)) % (2**32 - 1)


def run_path(key: str) -> Path:
    return RUN_DIRECTORY / f"{key}.npz"


def run_state_point(
    key: str,
    run_id: int,
    *,
    L: int,
    T: float,
    mu: float,
    epsilon: float,
    initial_density: float,
    n_sweeps_eq: int,
    n_sweeps_per_meas: int,
    n_meas: int,
) -> Path:
    destination = run_path(key)
    if destination.exists():
        print(f"cached  {key}")
        return destination

    seed = seed_for(run_id)
    started = time.perf_counter()
    result = lg.simulate_state_point(
        L=L,
        T=T,
        mu=mu,
        epsilon=epsilon,
        initial_density=initial_density,
        n_sweeps_eq=n_sweeps_eq,
        n_sweeps_per_meas=n_sweeps_per_meas,
        n_meas=n_meas,
        seed=seed,
        live_viz=False,
    )
    elapsed = time.perf_counter() - started

    metadata = {
        "key": key,
        "run_id": run_id,
        "L": L,
        "T": T,
        "mu": mu,
        "epsilon": epsilon,
        "initial_density": initial_density,
        "n_sweeps_eq": n_sweeps_eq,
        "n_sweeps_per_meas": n_sweeps_per_meas,
        "n_meas": n_meas,
        "seed": seed,
        "acceptance_equilibration": float(
            result["acceptance_equilibration"]
        ),
        "acceptance_sampling": float(result["acceptance_sampling"]),
        "elapsed_seconds": elapsed,
    }

    np.savez_compressed(
        destination,
        lattice=result["lattice"],
        energy_samples=result["energy_samples"],
        particle_samples=result["particle_samples"],
        structure_factor=result["structure_factor"],
        correlation=result["correlation"],
        metadata=np.asarray(json.dumps(metadata)),
    )
    print(
        f"ran     {key:26s}  L={L:2d}  T={T:.6f}  mu={mu:+.3f}  "
        f"n={n_meas:6d}  acc={metadata['acceptance_sampling']:.3f}  "
        f"{elapsed:.1f}s"
    )
    return destination


def add_job(jobs: list[dict], key: str, run_id: int, **parameters) -> None:
    jobs.append({"key": key, "run_id": run_id, **parameters})


def build_jobs() -> list[dict]:
    jobs: list[dict] = []

    # 3.2: noninteracting validation.
    for run_id, mu in enumerate((-1.0, 0.0, 1.0), start=1):
        p = np.exp(mu) / (1.0 + np.exp(mu))
        add_job(
            jobs,
            f"ideal_mu{mu:+.1f}",
            run_id,
            L=20,
            T=1.0,
            mu=mu,
            epsilon=0.0,
            initial_density=float(p),
            n_sweeps_eq=2_000,
            n_sweeps_per_meas=5,
            n_meas=12_000,
        )

    # 3.2: particle-hole symmetry.
    for offset, (mu, initial_density) in enumerate(
        ((MU_COEX - 0.4, 0.15), (MU_COEX + 0.4, 0.85)), start=4
    ):
        add_job(
            jobs,
            f"ph_mu{mu:+.1f}",
            offset,
            L=20,
            T=0.8,
            mu=mu,
            epsilon=EPSILON,
            initial_density=initial_density,
            n_sweeps_eq=5_000,
            n_sweeps_per_meas=5,
            n_meas=12_000,
        )

    # 3.3: equations of state.  The fine points at +/-0.05 provide a
    # symmetric finite-difference estimate at coexistence.
    mu_offsets = (-0.60, -0.40, -0.20, -0.10, -0.05, 0.0,
                  0.05, 0.10, 0.20, 0.40, 0.60)
    run_id = 10
    for ratio in (1.5, 1.15):
        for delta_mu in mu_offsets:
            if delta_mu < 0:
                initial_density = 0.15
            elif delta_mu > 0:
                initial_density = 0.85
            else:
                initial_density = 0.5
            add_job(
                jobs,
                f"eos_r{ratio:.2f}_dmu{delta_mu:+.2f}",
                run_id,
                L=24,
                T=ratio * TC,
                mu=MU_COEX + delta_mu,
                epsilon=EPSILON,
                initial_density=initial_density,
                n_sweeps_eq=6_000,
                n_sweeps_per_meas=5,
                n_meas=12_000,
            )
            run_id += 1

    # Additional near-coexistence resolution for the numerical derivative.
    # These use a separate run-id range so that cached runs above retain their
    # original seeds.
    run_id = 40
    for ratio in (1.5, 1.15):
        for delta_mu in (-0.02, -0.01, 0.01, 0.02):
            add_job(
                jobs,
                f"eos_r{ratio:.2f}_dmu{delta_mu:+.2f}",
                run_id,
                L=24,
                T=ratio * TC,
                mu=MU_COEX + delta_mu,
                epsilon=EPSILON,
                initial_density=0.15 if delta_mu < 0 else 0.85,
                n_sweeps_eq=6_000,
                n_sweeps_per_meas=5,
                n_meas=12_000,
            )
            run_id += 1

    for ratio in (1.5, 1.15):
        for delta_mu in (-0.005, 0.005):
            add_job(
                jobs,
                f"eosfine_r{ratio:.2f}_dmu{delta_mu:+.3f}",
                run_id,
                L=24,
                T=ratio * TC,
                mu=MU_COEX + delta_mu,
                epsilon=EPSILON,
                initial_density=0.15 if delta_mu < 0 else 0.85,
                n_sweeps_eq=8_000,
                n_sweeps_per_meas=5,
                n_meas=20_000,
            )
            run_id += 1

    # 3.4: independent replicates for S(k) and fit uncertainties.
    run_id = 100
    for ratio in (1.50, 1.25, 1.10, 1.05):
        for replicate in range(6):
            add_job(
                jobs,
                f"corr_r{ratio:.2f}_rep{replicate + 1}",
                run_id,
                L=24,
                T=ratio * TC,
                mu=MU_COEX,
                epsilon=EPSILON,
                initial_density=0.5,
                n_sweeps_eq=8_000,
                n_sweeps_per_meas=5,
                n_meas=10_000,
            )
            run_id += 1

    # 3.5: evolution of P_L(rho), including separate subcritical sectors.
    distribution_jobs = (
        ("dist_r1.20", 200, 1.20, 0.5),
        ("dist_r1.00", 201, 1.00, 0.5),
        ("dist_r0.90_low", 202, 0.90, 0.10),
        ("dist_r0.90_high", 203, 0.90, 0.90),
    )
    for key, this_id, ratio, initial_density in distribution_jobs:
        add_job(
            jobs,
            key,
            this_id,
            L=20,
            T=ratio * TC,
            mu=MU_COEX,
            epsilon=EPSILON,
            initial_density=initial_density,
            n_sweeps_eq=10_000 if ratio >= 1.0 else 6_000,
            n_sweeps_per_meas=5,
            n_meas=30_000,
        )

    # 3.5: two independent critical runs for each size.
    run_id = 300
    for L in (12, 16, 20, 24):
        for replicate in range(2):
            add_job(
                jobs,
                f"crit_L{L}_rep{replicate + 1}",
                run_id,
                L=L,
                T=TC,
                mu=MU_COEX,
                epsilon=EPSILON,
                initial_density=0.5,
                n_sweeps_eq=12_000,
                n_sweeps_per_meas=5,
                n_meas=40_000,
            )
            run_id += 1

    # Longer critical trajectories used for the displayed distribution and
    # first/second-half convergence diagnostic.  The shorter independent
    # pairs above remain the basis of the required two-run finite-size check.
    for key, this_id, L, measurements in (
        ("critlong_L20", 320, 20, 160_000),
        ("critlong_L24", 321, 24, 200_000),
    ):
        add_job(
            jobs,
            key,
            this_id,
            L=L,
            T=TC,
            mu=MU_COEX,
            epsilon=EPSILON,
            initial_density=0.5,
            n_sweeps_eq=12_000,
            n_sweeps_per_meas=5,
            n_meas=measurements,
        )

    return jobs


def main() -> None:
    print(f"Using supplied program: {PROGRAM}")
    print(f"T_c={TC:.9f}, mu_coex={MU_COEX:.6f}, base seed={BASE_SEED}")
    jobs = build_jobs()
    print(f"State points/replicates: {len(jobs)}")
    started = time.perf_counter()
    for job in jobs:
        run_state_point(**job)
    elapsed = time.perf_counter() - started
    print(f"All simulations available in {RUN_DIRECTORY} ({elapsed:.1f}s).")


if __name__ == "__main__":
    main()
